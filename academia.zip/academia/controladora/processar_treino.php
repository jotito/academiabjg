<?php
require '../repositorio/treino_repositorio.php';
require './conexao.php';
require '../modelo/treino.php';
if($_SERVER["REQUEST_METHOD"] =="POST"){
    $nome = $_POST["nome"];
    $descricao = $_POST["descricao"];
    $preco = $_POST["preco"];
    $imagem = $_POST["imagem"];

    $produto = new produto( 0,
        $nome,
        $descricao,
        $imagem,
        $preco,
    );
        $produtoRepositorio = new produtoRepositorio($conn);
        $produtoRepositorio->cadastrar($produto);
        header("Location: /academia/visao/cadastrar_treino_sucesso.php");

}
?>