<?php
include "./autenticacao.php";
include "./conexao.php";
if ($_SERVER["REQUEST_METHOD"]=="POST"){
    $email = $_POST["email"];
    $senha = $_POST["senha"];

    $login = new autenticacao($conn);
    $usuario = $login->verificarUsuario($email, $senha);
    if ($usuario){
        session_start();
        $_SESSION["usuario"] = $usuario;
        $_SESSION["nome_usuario"] = $usuario["nome"];
        header ("Location: /academia/visao/index.php");
        exit;
    }
    else{
        header ("Location: /academia/login.php?erro=1");
    }
}
?>