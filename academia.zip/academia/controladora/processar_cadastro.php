<?php
require '../modelo/personal.php';
require './conexao.php';

if($_SERVER["REQUEST_METHOD"] =="POST"){
    $nome = $_POST["nome"];
    $email = $_POST["email"];
    $senha = $_POST["senha"];
    $confirmarsenha = $_POST["confirmarsenha"];

    if ($senha === $confirmarsenha){
        //conexao com o banco de dados;
        $usuario = new Usuario($conn);
        //cadastrar o usuário
        if ($usuario->cadastrar($nome, $email, $senha)){
            //redirencionar para a paagina de sucesso após o cadasstro
            header("Location: /academia/visao/cadastro_personal_sucesso.php");
            exit();
        }
        else{
            echo "Erro! Tente novamente";
        }
    }
    else{
        header("Location: cadastro_personal.php?erro=1");
    }
}
?>