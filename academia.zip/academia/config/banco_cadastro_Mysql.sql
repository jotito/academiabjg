create database academia;
use academia;
create table usuario (id int auto_increment primary key,
nome varchar(255),
email varchar(255),
senha varchar(255));

select*from usuario;

create table produtos (
	id int not null auto_increment,
	nome varchar(45)not null,
	descricao varchar(90) not null,
	imagem varchar (80) not null,
	preco decimal (5,2) not null,
primary key (id));
select* from produtos;