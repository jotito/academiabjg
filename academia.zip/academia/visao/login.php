<!doctype html>
<html lang="pt-br">
<head>
  <meta charset="UTF-8">
  <meta name="viewport"
        content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <link rel="stylesheet" href="../recursos/css/reset.css">
  <link rel="stylesheet" href="../recursos/css/index.css">
  <link rel="stylesheet" href="../recursos/css/admin.css">
  <link rel="stylesheet" href="../recursos/css/form.css">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

  <link href="../recursos/img/favicon.png" rel="icon">
  <link href="../recursos/img/apple-touch-icon.png" rel="apple-touch-icon">
  
  <strong><title>INSTRUTOR - LOGIN</title></strong>
</head>
<body>
<main>
  <section class="container-admin-banner">
    <img src="../recursos/img/logo.png" class="logo-admin" alt="logo-serenatto">
    <h1>LOGIN INSTRUTOR</h1>
  </section>
  <section class="container-form">
  <form method="post" action = "../controladora/processar_login.php">

    <label for="email">E-mail</label>
    <input type="email" id="email" placeholder="Digite o seu e-mail" name="email" required>

    <label for="password">Senha</label>
    <input type="password" id="password" placeholder="Digite a sua senha" name="senha" required>

    <input type="submit" class="botao-cadastrar" value="Entrar"/>
  </form>

  <form method="post" action = "cadastro_personal.php">
      <input type="submit" class="botao-cadastrar" value="Novo Cadastro"/>
  </form>
   

  </section>
</main>
</body>
</html>