<!DOCTYPE html>
<html lang="pt-br">
  <?php
      session_start();
  ?>    
<head>
  <meta charset="utf-8">
  <meta content="width=device-width, initial-scale=1.0" name="viewport">

  <title>BJG FITNESS CLUB</title>
  <meta content="" name="description">
  <meta content="" name="keywords">

  <!-- Favicons -->
  <link href="../recursos/img/favicon.png" rel="icon">
  <link href="../recursos/img/apple-touch-icon.png" rel="apple-touch-icon">
  <!-- Google Fonts -->
  <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,600,600i,700,700i|Raleway:300,300i,400,400i,500,500i,600,600i,700,700i|Poppins:300,300i,400,400i,500,500i,600,600i,700,700i" rel="stylesheet">
  <!-- Vendor CSS Files -->
  <link href="../recursos/vendor/aos/aos.css" rel="stylesheet">
  <link href="../recursos/vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
  <link href="../recursos/vendor/bootstrap-icons/bootstrap-icons.css" rel="stylesheet">
  <link href="../recursos/vendor/boxicons/css/boxicons.min.css" rel="stylesheet">
  <link href="../recursos/vendor/glightbox/css/glightbox.min.css" rel="stylesheet">
  <link href="../recursos/vendor/remixicon/remixicon.css" rel="stylesheet">
  <link href="../recursos/vendor/swiper/swiper-bundle.min.css" rel="stylesheet">
  <!-- Template Main CSS File -->
  <link href="../recursos/css/style.css" rel="stylesheet">

</head>

<body>

  <!-- ======= Header ======= -->
  <header id="header" class="fixed-top ">
    <div class="container d-flex align-items-center justify-content-lg-between">

    <a href="index.php" class="logo me-auto me-lg-0"><img src="../recursos/img/logo.png" alt="" class="img-fluid"></a>

      <nav id="navbar" class="navbar order-last order-lg-0">
        <ul>
          <li><a class="nav-link scrollto active" href="#hero">Home</a></li>
          <li><a class="nav-link scrollto " href="#services">Treinos</a></li>
          <li><a class="nav-link scrollto " href="#counts">Sobre nós</a></li>
          <li><a class="nav-link scrollto" href="#testimonials">Alunos</a></li>
        </ul>
        <i class="bi bi-list mobile-nav-toggle"></i>
      </nav><!-- .navbar -->

      <a href="login.php" class="get-started-btn scrollto">Login Instrutor</a>
      <a href="cadastrar_treinos.php" class="get-started-btn scrollto">Treino</a>

    </div>
    <div class="menu">
        <div class="user-info dropdown">
            <div class="user-photo">
                <img src="../recursos/img/iconfoto.jpg" alt="Foto do Usuário">
            </div>
            <?php 
                if(isset( $_SESSION["nome_usuario"])) { 
                  echo "<div class= 'user-name'>" . $_SESSION["nome_usuario"] . "</div>";
                }
                else {
                  echo "<div class='user-name'>Logar</div>";
                }         
            ?>
            <div class="dropdown-content">
                <!-- Conteúdo do dropdown -->
                <a class="dropdown-item" href="#">Perfil</a>
                <a class="dropdown-item" href="#">Configurações</a>
                <a class="dropdown-item" href="#" onclick="logout()">Sair</a>
            </div>
        </div>
    </div>
    <script>
        function logout() {
        // Aqui você pode adicionar lógica para encerrar a sessão, por exemplo:
        // session_start();
        <?php session_destroy(); ?>

        // Redireciona para a página de login
        window.location.href = 'login.php';
    }
    </script>
  </header><!-- End Header -->

  <!-- ======= Home Section ======= -->
  <section id="hero" class="d-flex align-items-center justify-content-center">
    <div class="container" data-aos="fade-up">

      <div class="row justify-content-center" data-aos="fade-up" data-aos-delay="150">
        <div class="col-xl-6 col-lg-8">
          <h1>BJG FITNESS CLUB</h1>
          <h2>A academia que faz acontecer.</h2>
        </div>
      </div>


    </div>
  </section><!-- End Home -->

  <main id="main">

    <!-- ======= Services Section ======= -->
    <section id="services" class="services">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Treinos</h2>
          <p>Os nossos treinos</p>
        </div>

        <div class="row">
          <div class="col-lg-4 col-md-6 d-flex align-items-stretch" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
            
              <h4><a href="">Musculação</a></h4>
              <p>Fortaleça seu corpo e desenvolva músculos em nossa área de musculação totalmente equipada, projetada para atender
              a todos os níveis de condicionamento físico.</p>
              <br>
              <h4>R$ 100,00 por mês</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-md-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-file"></i></div>
              <h4><a href="">Spinning</a></h4>
              <p>Pedale para a boa forma! Nossas aulas de spinning oferecem um treino intenso de cardio, queimando calorias enquanto você pedala
              ao ritmo de músicas motivadoras.</p>
              <br>
              <h4>R$ 80,00 por mês</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4 mt-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <h4><a href="">Pilates</a></h4>
              <p>Aprimore sua postura, flexibilidade e força no Pilates. Nossas aulas se concentram no equilíbrio entre mente e corpo,
                proporcionando um treinamento eficaz e de baixo impacto.</p>
                <br>
              <h4>R$ 60,00 por mês</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-world"></i></div>
              <h4><a href="">Dança</a></h4>
              <p>Mexa-se ao som da música! Oferecemos aulas de dança que tornam o exercício uma diversão, melhorando a coordenação,
                o condicionamento cardiovascular e a expressão corporal.</p>
                <br>
              <h4>R$ 75,00 por mês</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-slideshow"></i></div>
              <h4><a href="">Muay Thai</a></h4>
              <p>Entre no ringue com nosso treinamento de Muay Thai. Desenvolva habilidades de autodefesa, força e resistência, 
                enquanto aprende a arte do combate tailandês.</p>
                <br>
              <h4>R$ 90,00 por mês</a></h4>
            </div>
          </div>

          <div class="col-lg-4 col-md-6 d-flex align-items-stretch mt-4" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box">
              <div class="icon"><i class="bx bx-arch"></i></div>
              <h4><a href="">CrossFit</a></h4>
              <p>Treinamento funcional de alta intensidade para resultados rápidos.</p>
              <br>
              <h4>R$ 80,00 por mês</a></h4>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->


    <!-- ======= Counts Section ======= -->
    <section id="counts" class="counts">
      <div class="container" data-aos="fade-up">

        <div class="row no-gutters">
          <div class="image col-xl-5 d-flex align-items-stretch justify-content-center justify-content-lg-start"></div>
          <div class="col-xl-7 ps-4 ps-lg-5 pe-4 pe-lg-1 d-flex align-items-stretch border-radius">
            <div class="content d-flex flex-column justify-content-center">
              <h3>Sobre nós</h3>
              <p>
                Somos mais que uma academia; somos uma comunidade comprometida com a saúde, bem-estar e superação, oferecendo instalações de ponta e orientação
                profissional para alcançar seus objetivos de forma eficaz. Junte-se a nós e faça parte de uma jornada fitness incrível!
              </p>
              <div class="row">
                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-emoji-smile"></i>
                    <span data-purecounter-start="0" data-purecounter-end="300" data-purecounter-duration="2" class="purecounter"></span>
                    <p><strong>Avaliações positivas</strong> no Google.</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-journal-richtext"></i>
                    <span data-purecounter-start="0" data-purecounter-end="23" data-purecounter-duration="2" class="purecounter"></span>
                    <p><strong>Profissionais</strong> qualificados para atender as suas necessidades, incluindo personal trainers.</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-clock"></i>
                    <span data-purecounter-start="0" data-purecounter-end="10" data-purecounter-duration="2" class="purecounter"></span>
                    <p><strong>Anos de experiência</strong> atuando como uma das academias mais modernas do Brasil.</p>
                  </div>
                </div>

                <div class="col-md-6 d-md-flex align-items-md-stretch">
                  <div class="count-box">
                    <i class="bi bi-award"></i>
                    <span data-purecounter-start="0" data-purecounter-end="20" data-purecounter-duration="2" class="purecounter"></span>
                    <p><strong>Medalhas</strong> de destaque em campeonatos nacionais de CrossFit.</p>
                  </div>
                </div>
              </div>
            </div><!-- End .content-->
          </div>
        </div>

      </div>
    </section><!-- End Counts Section -->

    <!-- ======= Testimonials Section ======= -->
    <section id="testimonials" class="testimonials">
      <div class="container" data-aos="zoom-in">

        <div class="testimonials-slider swiper" data-aos="fade-up" data-aos-delay="100">
          <div class="swiper-wrapper">

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="../recursos/img/testimonials/testimonials-1.jpg" class="testimonial-img" alt="">
                <h3>Gustavo Emanuel Cardoso</h3>
                <h4>Aluno</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  A BJG FITNESS CLUB é simplesmente incrível! As instalações são de primeira classe, os instrutores são super prestativos e as aulas de
                  spinning são minha paixão. Esta academia me ajudou a atingir minhas metas de condicionamento físico de maneira divertida e eficaz.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="../recursos/img/testimonials/testimonials-2.jpg" class="testimonial-img" alt="">
                <h3>Bianca Rodrigues Batalini</h3>
                <h4>Aluna</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  A BJG FITNESS CLUB é top! Equipamentos modernos e instrutores super atenciosos.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="../recursos/img/testimonials/testimonials-3.jpg" class="testimonial-img" alt="">
                <h3>João Rodrigues Batalini</h3>
                <h4>Aluno</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  O Muay Thai na BJG FITNESS CLUB me desafiou fisicamente e mentalmente. Os instrutores são apaixonados
                  e experientes. É um ótimo lugar para aprender e praticar essa arte marcial.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="../recursos/img/testimonials/testimonials-4.jpg" class="testimonial-img" alt="">
                <h3>Neemias Felix</h3>
                <h4>Aluno</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  Adoro o CrossFit na BJG. Treinos intensos, galera animada.
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->

            <div class="swiper-slide">
              <div class="testimonial-item">
                <img src="../recursos/img/testimonials/testimonials-5.jpg" class="testimonial-img" alt="">
                <h3>Leonardo Gomes de Manoel</h3>
                <h4>Aluno</h4>
                <p>
                  <i class="bx bxs-quote-alt-left quote-icon-left"></i>
                  A BJG FITNESS CLUB é minha segunda casa. O CrossFit é meu vício, e esta academia oferece uma
                  comunidade solidária e instalações de alta qualidade. Estou mais forte e confiante do que nunca!
                  <i class="bx bxs-quote-alt-right quote-icon-right"></i>
                </p>
              </div>
            </div><!-- End testimonial item -->
          </div>
          <div class="swiper-pagination"></div>
        </div>

      </div>
    </section><!-- End Testimonials Section -->

    <!-- ======= Sessão Contato ======= -->
    <section id="contact" class="contact">
      <div class="container" data-aos="fade-up">

        <div class="section-title">
          <h2>Contato</h2>
          <p>Nossos Contatos</p>
        </div>

        <div class="row mt-5">

          <div class="col-lg-4">
            <div class="info">
              <div class="address">
                <i class="bi bi-geo-alt"></i>
                <h4>Endereço:</h4>
                <p>A108 Adam Street, New York, NY 535022</p>
              </div>

              <div class="email">
                <i class="bi bi-envelope"></i>
                <h4>Email:</h4>
                <p>bjgfitnessclub@gmail.com</p>
              </div>

              <div class="phone">
                <i class="bi bi-phone"></i>
                <h4>Telefone:</h4>
                <p>+1 5589 55488</p>
              </div>

            </div>

          </div>

        </div>

      </div>
    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-3 col-md-6">
            <div class="footer-info">
              <h3>BJG<span>.</span></h3>
              <p>
                A108 Adam Street <br>
                NY 535022, USA<br><br>
                <strong>Telefone:</strong> +1 5589 55488 55<br>
                <strong>Email:</strong> info@example.com<br>
              </p>
              <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
            </div>
          </div>

          <div class="col-lg-2 col-md-6 footer-links">
            <h4>Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#hero">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#services">Treinos</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#counts">Sobre nós</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#testimonials">Alunos</a></li>
            </ul>
          </div>

          <div class="col-lg-4 col-md-6 footer-newsletter">
            <h4>Our Newsletter</h4>
            <p>Tamen quem nulla quae legam multos aute sint culpa legam noster magna</p>
            <form action="" method="post">
              <input type="email" name="email"><input type="submit" value="Subscribe">
            </form>

          </div>

        </div>
      </div>
    </div>

    <div class="container">
      <div class="copyright">
        &copy; Copyright <strong><span>BGJ Academia</span></strong> Todos os direitos reservados
      </div>
    </div>
  </footer><!-- End Footer -->

  <div id="preloader"></div>
  <a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="bi bi-arrow-up-short"></i></a>


  <!-- Vendor JS Files -->
  <script src="../recursos/vendor/purecounter/purecounter_vanilla.js"></script>
  <script src="../recursos/vendor/aos/aos.js"></script>
  <script src="../recursos/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="../recursos/vendor/glightbox/js/glightbox.min.js"></script>
  <script src="../recursos/vendor/isotope-layout/isotope.pkgd.min.js"></script>
  <script src="../recursos/vendor/swiper/swiper-bundle.min.js"></script>
  <script src="../recursos/vendor/php-email-form/validate.js"></script>

  <!-- Template Main JS File -->
  <script src="../recursos/js/main.js"></script>

</body>

</html>